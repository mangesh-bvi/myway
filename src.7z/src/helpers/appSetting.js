let appSetting = {
  APIURL:"http://vizio.atafreight.com/mywayapi/",
 // APIURL: "http://vizio.atafreight.com/MyWayAPIReplica/",
  Keys: "AIzaSyAdUg5RYhac4wW-xnx-p0PrmKogycWz9pI"
  // Keys:"AIzaSyC8HmfVPz8zjUtcBIv01E_5ZYWE3l8vgZE"
};

export default appSetting;
