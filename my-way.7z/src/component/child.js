export default ({children})=>children;
